<?php
session_start();
header('Content-Type: application/json');
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Connessione al database
$host = "localhost";
$db = "GoToMarconi";
$user = "root";
$pass = "";
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'error' => 'Errore di connessione al database']);
    exit();
}

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Utente non autenticato.']);
    exit();
}

$input = json_decode(file_get_contents("php://input"), true);
$id_viaggio = isset($input['id_viaggio']) ? intval($input['id_viaggio']) : 0;
$id_passeggero = $_SESSION['user_id'];

if (!$id_viaggio) {
    echo json_encode(['success' => false, 'message' => 'ID viaggio non valido.']);
    exit();
}

// Verifica se ci sono già richieste inviate
$stmt = $conn->prepare("SELECT ID FROM Prenotazione WHERE ID_Passeggero = ? AND ID_Viaggio = ?");
$stmt->bind_param("ii", $id_passeggero, $id_viaggio);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'Hai già inviato una richiesta per questo viaggio.']);
    $stmt->close();
    exit();
}
$stmt->close();

// Verifica che il viaggio abbia posti disponibili
$stmt = $conn->prepare("SELECT Posti FROM Viaggio WHERE ID = ?");
$stmt->bind_param("i", $id_viaggio);
$stmt->execute();
$result = $stmt->get_result();
$viaggio = $result->fetch_assoc();
$stmt->close();

if (!$viaggio || $viaggio['Posti'] <= 0) {
    echo json_encode(['success' => false, 'message' => 'Il viaggio non ha posti disponibili.']);
    exit();
}

// Inserisci richiesta
$stato = "in_attesa";  // ✅ Corretto per farle apparire in autista.php
$stmt = $conn->prepare("INSERT INTO Prenotazione (ID_Passeggero, ID_Viaggio, Stato) VALUES (?, ?, ?)");

$stmt->bind_param("iis", $id_passeggero, $id_viaggio, $stato);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Richiesta inviata con successo!']);
} else {
    echo json_encode(['success' => false, 'message' => 'Errore nell\'invio della richiesta.']);
}
$stmt->close();
$conn->close();
?>
