<?php
session_start();
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "GoToMarconi");
if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Errore di connessione"]);
    exit;
}

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["success" => false, "message" => "Utente non autenticato"]);
    exit;
}

$input = json_decode(file_get_contents("php://input"), true);
$id_richiesta = intval($input['id_richiesta'] ?? 0);
$azione = $input['azione'] ?? '';

if (!$id_richiesta || !in_array($azione, ['accetta', 'rifiuta'])) {
    echo json_encode(["success" => false, "message" => "Parametri mancanti o invalidi"]);
    exit;
}

$stato = ($azione === 'accetta') ? 'Accettata' : 'Rifiutata';

// Ottieni ID_Viaggio
$stmt = $conn->prepare("SELECT ID_Viaggio FROM Prenotazione WHERE ID = ?");
$stmt->bind_param("i", $id_richiesta);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$stmt->close();

if (!$row) {
    echo json_encode(["success" => false, "message" => "Richiesta non trovata"]);
    exit;
}

$id_viaggio = $row['ID_Viaggio'];

// Aggiorna stato richiesta
$stmt = $conn->prepare("UPDATE Prenotazione SET Stato = ? WHERE ID = ?");
$stmt->bind_param("si", $stato, $id_richiesta);
$stmt->execute();
$stmt->close();

// Se accettata, riduci posti
if ($stato === 'Accettata') {
    $stmt = $conn->prepare("UPDATE Viaggio SET Posti = Posti - 1 WHERE ID = ? AND Posti > 0");
    $stmt->bind_param("i", $id_viaggio);
    $stmt->execute();
    $stmt->close();
}

echo json_encode(["success" => true, "message" => "✅ Richiesta $stato con successo"]);
$conn->close();
?>
